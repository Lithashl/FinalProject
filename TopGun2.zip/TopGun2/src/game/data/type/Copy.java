package game.data.type;

public interface Copy {
    public Object getCopy();
}
